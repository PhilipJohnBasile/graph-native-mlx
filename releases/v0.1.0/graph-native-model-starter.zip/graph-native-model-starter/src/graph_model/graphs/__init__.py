"""Bundled validated graph specifications."""
